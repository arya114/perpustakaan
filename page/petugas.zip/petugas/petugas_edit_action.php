<?php
// include database connection file
$koneksi = new mysqli ("localhost","root","","db_perpustakaann");
 
// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{    
    $kode_petugas = $_POST['kode_petugas'];
    
        $nama = $_POST['nama'];
        $jk = $_POST['jk'];
        $jabatan = $_POST['jabatan'];
        $telpon = $_POST['telpon'];
        $alamat = $_POST['alamat'];
        $jam_tugas = $_POST['jam_tugas'];
        
    // update user data
    $result = mysqli_query($koneksi, "UPDATE petugas SET nama='$nama',jk='$jk',jabatan='$jabatan',telpon='$telpon',alamat='$alamat',jam_tugas='$jam_tugas' WHERE kode_petugas=$kode_petugas");
    
    // Redirect to homepage to display updated user in list
    header("Refresh:0; url='http://localhost/perpus/?page=petugas'"); 
}
?>
